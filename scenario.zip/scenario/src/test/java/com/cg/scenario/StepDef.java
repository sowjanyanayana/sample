package com.cg.scenario;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	WebDriver driver = null;
	Web factory = null;

	@Given("^user is on registration page$")
	public void user_is_on_registration_page() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\snayana\\Documents\\chromedriver.exe");
		driver = new ChromeDriver();
		factory = new Web(driver);
		driver.get("file:///D:/servlet/jsp/WebContent/register.html");
	}

	@When("^user enters (\\d+)$")
	public void user_enters(Integer pno) throws Exception {
		factory.setName("sowjanya");
		factory.setMobileNumber(pno.toString());
		factory.setButton();
	}

	@Then("^display appropriate message$")
	public void display_appropriate_message() throws Exception {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("not matched " + alertMessage);
		
	}

	@When("^user enters number$")
	public void user_enters_number(DataTable number) throws Exception {
		factory.setName("sowjanya");
		List<String> list = number.asList(String.class);
		String data = null;
		for (String dataTemp : list) {
			data = dataTemp;
			factory.getMobileNumber().clear();
			factory.setMobileNumber(dataTemp);
			Thread.sleep(1000);
			factory.setButton();

			if (Pattern.matches("^[6-9]{1}[0-9]{9}$", data)) {
				System.out.println("Matching ");
			}else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				System.out.println("not matched " + alertMessage);
			}
			
		}	
	
	}
	}


